<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $estoque = 57;
    echo "A quantidade de produto no estoque é: $estoque"
    ?>
    
</body>
</html>